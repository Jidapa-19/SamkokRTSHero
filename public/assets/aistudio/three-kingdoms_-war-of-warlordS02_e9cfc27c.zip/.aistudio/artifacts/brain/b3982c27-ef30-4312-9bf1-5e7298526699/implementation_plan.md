# Three Kingdoms: War of Warlords (V0.1)

A browser-based real-time grand strategy game set in the Three Kingdoms era of ancient China, featuring an interactive ink-wash parchment HTML5 Canvas map, live marching and combat simulation, procedural audio feedback, and bilingual English/Thai localization.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following core design and simulation choices have been confirmed from your answers and integrated into the V0.1 architecture:

- **Confirmed Decision 1 — Live English & Thai Language Toggle**: The entire interface, including faction descriptions, historical general names, troop types, city inspectors, command buttons, and real-time battle logs, supports instant switching between **English (`EN`)** and **Thai (`TH` — สามก๊ก: สงครามจอมราชันย์)**.
- **Confirmed Decision 2 — Live Real-Time Marching, Combat & Resource Ticks**: Rather than static placeholders, V0.1 features a live real-time game loop where armies physically march along road connections between cities, clash with rival armies or city garrisons using troop-counter multipliers, capture territories, and collect periodic Gold and Supply yields.
- **Confirmed Decision 3 — Ink-Wash Parchment Map & Procedural Web Audio**: The strategic map renders purely via HTML5 Canvas with antique parchment textures, procedural mountain ranges, the Yellow and Yangtze rivers, road networks, city fortifications, and animated army banners—accompanied by zero-dependency Web Audio API synthesized sound effects (war drums, marching steps, blade clashes, and victory horns) with a quick mute toggle.

---

## 1. Overview & Core Concept

- **What It Does**: Players step into the role of a warlord leading **Wei (วุยก๊ก)**, **Shu (จ๊กก๊ก)**, or **Wu (ง่อก๊ก)** across an interactive top-down strategic map of ancient China. Players inspect cities, recruit four distinct troop types, mobilize armies led by famous generals, issue real-time movement and attack orders along connected road routes, fortify city walls, and expand their territory.
- **Target Audience / Persona**: Strategy and historical wargame players on desktop and mobile browsers seeking a responsive, tactile real-time tactical experience that loads instantaneously without external asset dependencies.
- **Key Value**: Combines a 60fps HTML5 Canvas cartographic viewport with a modular TypeScript real-time simulation engine and resilient local save/load state management, establishing a clean foundation for future AI warlord behaviors and large-scale campaigns.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Title & Faction Selection Screen**:
   - Opens with a full-viewport Game Shell displaying a live slowly panning ink-wash background of the Central Plains, a bespoke SVG Imperial Seal title lockup, and a language selector (`EN` / `ภาษาไทย`).
   - Players inspect the three playable kingdoms—**Wei (Cao Cao)**, **Shu (Liu Bei)**, and **Wu (Sun Quan)**—comparing starting cities, gold, supplies, and military strength before clicking **Start Campaign** (or **Load Saved Campaign** if a valid save exists in LocalStorage).
2. **Strategic Map Exploration (Pan, Zoom & Inspect)**:
   - Players pan across the map via mouse drag, touch drag, or `WASD` / Arrow keys, and zoom smoothly around the cursor or pinch center (`0.55x` to `2.2x`) without triggering mobile page scrolling.
   - Clicking any of the 8 strategic cities (**Luoyang, Xuchang, Ye, Chengdu, Hanzhong, Jianye, Jingzhou, Xiangyang**) opens the **City Information Panel** and highlights connected road routes.
   - Clicking any army banner opens the **Army Information Panel** and **Command Panel**.
3. **Issuing Real-Time Orders & Managing Territories**:
   - **City Management**: When inspecting an owned city, players can spend Gold and Supplies to **Recruit Garrison**, **Upgrade City Walls**, or **Mobilize New Army** with custom troop compositions.
   - **Army Commands**: When commanding a friendly army, players can toggle **Move Army** or **Attack** mode (highlighting valid connected destination cities on the map canvas), switch into a fortified **Defend** stance (`+25%` defense bonus), or execute **Capture City** when positioned over a neutral or defeated stronghold.
4. **Game Loop & Persistence Controls**:
   - Players can **Pause / Resume** (`Space`), adjust simulation speed (`1x` / `2x`), **Save Game**, **Load Game**, or **Reset Campaign** at any time, with instant toast confirmation and Battle Event Log entries.

### Visual Identity & Theme
- **Aesthetic Direction**: *Ancient Chinese Imperial War Room (Ink-Wash & Antique Parchment)*. Dark ink-charcoal perimeter panels frame a warm antique silk-parchment cartographic canvas with bronze hairline borders.
- **Color Palette & Mood (60-30-10 Allocation)**:
  - **60% Dominant Map & Surface Canvas**: Warm aged parchment (`#DFD3B8` to `#C8B692`) on the strategic map canvas; deep ink-stone (`#141311` and `#1E1C18`) for compact perimeter HUD panels.
  - **30% Structural Typography & Borders**: Aged bone text (`#F3ECE0`), muted bamboo-ash metadata (`#A89F8E`), and antique bronze hairline dividers (`#4A3F2F`).
  - **10% Faction & Action Accents**:
    - **Wei (วุยก๊ก)**: Imperial Cobalt Blue (`#2563EB` / `#60A5FA`)
    - **Shu (จ๊กก๊ก)**: Jade Vermilion Emerald (`#059669` / `#34D399`)
    - **Wu (ง่อก๊ก)**: Sun Crimson & Gold (`#DC2626` / `#F87171`)
    - **Neutral / Han Remnants**: Stone Amber (`#78716C` / `#D6D3D1`)
    - **Primary Interactive Accent**: Imperial Gold (`#D97706` / `#F59E0B`)
- **Typography & Hierarchy**:
  - **Display & Headings**: `Cinzel` paired with `Noto Serif Thai` for authoritative imperial headers and city titles.
  - **Body & UI Controls**: `Plus Jakarta Sans` paired with `Noto Sans Thai` for crisp legibility at compact HUD sizes.
  - **Numeric Readouts**: Monospace `JetBrains Mono` with `tabular-nums` for gold, supplies, troop counts, and combat stats so real-time ticks never jitter horizontally.
- **Component Styling & Low-Occlusion HUD**:
  - At least 85% of the viewport remains unobstructed strategic map canvas.
  - Perimeter HUD panels use solid dark ink surfaces (`#181613`) with crisp 1px bronze borders (`#3D3426`)—avoiding `backdrop-filter` over the active HTML5 Canvas to guarantee 60fps rendering performance.
  - Responsive layout: On desktop (`>= 1024px`), inspector and command panels dock neatly on the left and right edges while the battle log and controls sit compactly at the bottom. On mobile (`< 1024px`), inspector panels slide up as a compact bottom drawer when a city or army is selected.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Decoupled 60fps Canvas Render Loop vs. React State Simulation Tick**
  - *Chosen Approach*: Camera pan/zoom coordinates, hover states, and smooth army interpolation run inside a dedicated `requestAnimationFrame` Canvas loop, while strategic game state updates (resource production, combat rounds, arrival events) execute on a controlled simulation tick (`useGameState`) that cleanly pauses and resumes.
  - *Why*: Prevents React re-renders on every mouse drag or wheel zoom frame while keeping React panels immediately synchronized when a city or army state changes.
  - *Alternatives Considered*: Driving camera pan/zoom through React state, which causes frame drops on mobile browsers.

- **Decision 2: Rock-Paper-Scissors Troop Composition & Tactical Stances**
  - *Chosen Approach*: Each army's combat effectiveness is dynamically calculated from its four troop types (**Spearmen** counter **Cavalry**; **Cavalry** flank **Archers**; **Archers** rain fire on **Spearmen**; **Sword & Shield Infantry** provide high baseline armor and siege durability) plus the assigned **General's** attack/defense modifiers and city wall levels.
  - *Why*: Makes troop composition and general assignment meaningful immediately in V0.1 when attacking or defending cities.

- **Decision 3: Schema-Validated LocalStorage Persistence**
  - *Chosen Approach*: Save data is serialized with a versioned schema envelope and deep structural validation on load (verifying faction IDs, city arrays, numeric bounds, and army references). Corrupted or incompatible JSON triggers a graceful user notification and fallback without crashing the application.
  - *Why*: Directly satisfies the engineering requirement for resilient local save/load handling.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌────────────────────────────────────────────────────────────────────────────┐
│                       App Shell & Language Provider                        │
│        (Game Mode: TITLE_SELECT │ PLAYING │ PAUSED │ VICTORY_MODAL)        │
└───────────────────┬────────────────────────────────────┬───────────────────┘
                    │                                    │
                    ▼                                    ▼
┌───────────────────────────────────────┐  ┌─────────────────────────────────┐
│      useGameState (RTS Engine)        │  │  Web Audio Synthesizer & Storage│
│  • Real-time Tick Loop (Pause/Resume) │  │  • Procedural Drums/Horn/Clash  │
│  • Road Graph Marching & Interpolation│◄─┼─►• Validated LocalStorage I/O   │
│  • Combat Resolver & City Capture     │  │  • Corrupted Save Recovery      │
│  • Resource Yield & Troop Recruitment │  └─────────────────────────────────┘
└─────────┬───────────────────┬─────────┘
          │                   │
          ▼                   ▼
┌───────────────────┐ ┌──────────────────────────────────────────────────────┐
│ 60fps HTML5 Canvas│ │              Perimeter HUD Overlay Panels            │
│    (GameMap)      │ │  ┌──────────────────┐  ┌──────────────────────────┐  │
│ • Parchment & Ink │ │  │      TopBar      │  │   GameControls & Audio   │  │
│ • Rivers & Peaks  │ │  └──────────────────┘  └──────────────────────────┘  │
│ • Road Network    │ │  ┌──────────────────┐  ┌──────────────────────────┐  │
│ • 8 City Nodes    │ │  │    CityPanel     │  │   ArmyPanel & Commands   │  │
│ • Army Banners    │ │  │ (Inspect/Recruit)│  │ (Move/Attack/Defend/Cap) │  │
│ • Pan/Pinch/Zoom  │ │  └──────────────────┘  └──────────────────────────┘  │
└───────────────────┘ │  ┌────────────────────────────────────────────────┐  │
                      │  │           BattleLog (Real-Time Feed)           │  │
                      │  └────────────────────────────────────────────────┘  │
                      └──────────────────────────────────────────────────────┘
```

### Data Model & State
- **`Faction`**: `id` (`wei` | `shu` | `wu` | `neutral`), bilingual `name` & `leaderName`, distinct primary/secondary hex colors, `gold`, `supplies`, `ownedCityIds`, and computed `totalMilitaryStrength`.
- **`City`**: `id`, bilingual `name`, map `position {x, y}`, `ownerFactionId`, `level` / `population`, `garrison`, `wallLevel`, `goldYield`, `supplyYield`, and `connectedCityIds` defining the road network across:
  - **Ye (เย่)**, **Luoyang (ลกเอี๋ยง)**, **Xuchang (ฮูโต๋)**, **Hanzhong (ฮันต๋ง)**, **Chengdu (เฉิงตู)**, **Xiangyang (ซงหยง)**, **Jingzhou (เกงจิ๋ว)**, and **Jianye (เจี้ยนเย่)**.
- **`TroopType` & Composition**:
  - `spearmen` (พลหอก — bonus vs. Cavalry)
  - `cavalry` (พลม้า — high speed, flanking bonus vs. Archers)
  - `archers` (พลธนู — ranged attack, fragile close defense)
  - `infantry` (พลดาบโล่ — high defense and siege resilience)
- **`General`**: `id`, bilingual `name` & `title` (e.g., Zhang Liao, Cao Ren, Guan Yu, Zhuge Liang, Zhao Yun, Zhou Yu, Lu Xun, Gan Ning), `attackBonus`, `defenseBonus`, and `speedBonus`.
- **`Army`**: `id`, bilingual `name`, `ownerFactionId`, `position {x, y}`, `currentCityId`, `targetCityId`, `movementProgress` (`0..1`), `troops` (`Record<TroopType, number>`), `totalTroops`, `general`, `attackStat`, `defenseStat`, and `status` (`idle` | `marching` | `attacking` | `defending` | `capturing`).
- **`BattleEvent`**: `id`, `timestamp`, `type` (`movement` | `combat` | `capture` | `economy` | `system`), and bilingual message payload.

### Interactive Component & State Mapping
- **`TopBar`**: Displays game title, current faction emblem, live Gold, Supplies, Total Troops, Owned Cities count, and quick `EN/TH` language switch.
- **`GameMap` (HTML5 Canvas)**:
  - Handles `ResizeObserver` for crisp devicePixelRatio scaling on desktop and mobile.
  - Supports left-drag / single-touch pan, mouse-wheel / two-finger pinch zoom, and click/tap hit-testing for cities and armies.
  - When the player activates **Move** or **Attack** command mode, valid connected target cities pulse with an interactive target ring on the canvas; clicking a highlighted city dispatches the marching/attack order immediately.
- **`CityPanel`**: Displays city owner, population/level, garrison count, wall level, connected roads, and functional action buttons: **Recruit Garrison (+300 Troops)**, **Reinforce Walls (+1 Wall Level)**, and **Deploy New Field Army**.
- **`ArmyPanel` & Command Panel**: Shows general portrait seal, troop count breakdown across all 4 unit types, computed Attack/Defense rating, movement status progress bar, and the 4 core tactical commands (**Move Army**, **Attack Target**, **Defend Position**, **Capture City**) plus **Reinforce from City**.
- **`BattleLog` & `GameControls`**: Streams color-coded strategic events with timestamps and provides one-click **Pause / Resume**, **1x / 2x Speed**, **Save Game**, **Load Game**, **Mute Audio**, and **Switch Faction / Restart**.
