import { useEffect, useState } from 'react';
import { Castle, Swords, ScrollText, Map as MapIcon, Trophy } from 'lucide-react';
import { ArmyPanel } from './components/ArmyPanel';
import { BattleLog } from './components/BattleLog';
import { CityPanel } from './components/CityPanel';
import { FactionSelectScreen } from './components/FactionSelectScreen';
import { GameControls } from './components/GameControls';
import { GameMap } from './components/GameMap';
import { TopBar } from './components/TopBar';
import { Language } from './game/types';
import { useGameState } from './hooks/useGameState';
import { soundFX } from './utils/sound';

type MobileDrawerTab = 'none' | 'city' | 'army' | 'log';

export default function App() {
  const {
    gameState,
    toast,
    hasSavedGame,
    startCampaign,
    resetToTitle,
    selectCity,
    handleCityClickOnMap,
    selectArmy,
    setCommandMode,
    orderArmyToCity,
    retreatArmy,
    setArmyDefend,
    captureCityWithArmy,
    recruitCityGarrison,
    upgradeCityWalls,
    reinforceArmyTroops,
    mobilizeNewArmy,
    togglePause,
    setSpeed,
    saveGame,
    loadGame,
  } = useGameState();

  const [lang, setLang] = useState<Language>('en');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [mobileTab, setMobileTab] = useState<MobileDrawerTab>('none');

  const handleToggleLang = () => {
    soundFX.playSelect();
    setLang((prev) => (prev === 'en' ? 'th' : 'en'));
  };

  const handleToggleMute = () => {
    const muted = soundFX.toggleMute();
    setIsMuted(muted);
  };

  // Spacebar shortcut to Pause / Resume when playing
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (gameState.screen !== 'playing') return;
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA' ||
        document.activeElement?.tagName === 'BUTTON'
      ) {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        togglePause();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [gameState.screen, togglePause]);

  // Derived active objects
  const playerFaction = gameState.factions[gameState.playerFactionId];
  const selectedCity =
    gameState.cities.find((c) => c.id === gameState.selectedCityId) || null;
  const selectedArmy =
    gameState.armies.find((a) => a.id === gameState.selectedArmyId) || null;
  const armiesAtSelectedCity = selectedCity
    ? gameState.armies.filter((a) => a.currentCityId === selectedCity.id)
    : [];
  const playerArmies = gameState.armies.filter(
    (a) => a.ownerFactionId === gameState.playerFactionId
  );

  // Title / Faction Selection Screen
  if (gameState.screen === 'faction_select') {
    return (
      <FactionSelectScreen
        initialFaction={gameState.playerFactionId}
        hasSavedGame={hasSavedGame}
        lang={lang}
        isMuted={isMuted}
        onToggleLang={handleToggleLang}
        onToggleMute={handleToggleMute}
        onStartCampaign={startCampaign}
        onLoadSavedGame={loadGame}
      />
    );
  }

  return (
    <div className="w-screen h-screen overflow-hidden flex flex-col bg-[#12100E] text-[#F3ECE0]">
      {/* 1. Top Resource Bar */}
      <TopBar
        playerFaction={playerFaction}
        cities={gameState.cities}
        seasonYear={gameState.seasonYear}
        lang={lang}
        onToggleLang={handleToggleLang}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onOpenFactionSelect={resetToTitle}
      />

      {/* 2. Main Interactive Map & Low-Occlusion Perimeter Panels */}
      <main className="relative flex-1 w-full overflow-hidden">
        {/* Strategic Map Canvas (100% background fill) */}
        <GameMap
          cities={gameState.cities}
          armies={gameState.armies}
          factions={gameState.factions}
          selectedCityId={gameState.selectedCityId}
          selectedArmyId={gameState.selectedArmyId}
          commandMode={gameState.commandMode}
          combatEffects={gameState.combatEffects}
          lang={lang}
          onSelectCity={(cityId) => {
            handleCityClickOnMap(cityId);
            if (gameState.commandMode === 'none') {
              setMobileTab('city');
            }
          }}
          onSelectArmy={(armyId) => {
            selectArmy(armyId);
            setMobileTab('army');
          }}
          onCancelCommandMode={() => setCommandMode('none')}
        />

        {/* Toast Feedback Notification */}
        {toast && (
          <div className="fixed top-14 left-1/2 -translate-x-1/2 z-30 pointer-events-none px-4 py-2 rounded bg-[#181613] border border-[#D97706] shadow-xl text-xs sm:text-sm font-medium text-[#F3ECE0]">
            {toast.text[lang]}
          </div>
        )}

        {/* Desktop Left Dock: City Information Panel & Battle Event Log */}
        <div className="hidden lg:flex flex-col justify-between pointer-events-none absolute top-3 bottom-3 left-3 w-80 xl:w-84 z-10 gap-3">
          <div className="pointer-events-auto overflow-y-auto max-h-[calc(100%-11rem)]">
            <CityPanel
              city={selectedCity}
              allCities={gameState.cities}
              armiesAtCity={armiesAtSelectedCity}
              activeBattles={gameState.activeBattles}
              factions={gameState.factions}
              playerFactionId={gameState.playerFactionId}
              lang={lang}
              onRecruitGarrison={recruitCityGarrison}
              onUpgradeWalls={upgradeCityWalls}
              onMobilizeArmy={mobilizeNewArmy}
              onSelectCity={selectCity}
              onSelectArmy={selectArmy}
            />
          </div>

          <div className="pointer-events-auto shrink-0">
            <BattleLog events={gameState.battleLog} lang={lang} />
          </div>
        </div>

        {/* Desktop Right Dock: Army Information Panel, Command Panel & Game Controls */}
        <div className="hidden lg:flex flex-col justify-between pointer-events-none absolute top-3 bottom-3 right-3 w-80 xl:w-84 z-10 gap-3">
          <div className="pointer-events-auto overflow-y-auto max-h-[calc(100%-4.5rem)]">
            <ArmyPanel
              army={selectedArmy}
              playerArmies={playerArmies}
              cities={gameState.cities}
              factions={gameState.factions}
              playerFactionId={gameState.playerFactionId}
              commandMode={gameState.commandMode}
              lang={lang}
              onSelectArmy={selectArmy}
              onSetCommandMode={setCommandMode}
              onOrderArmyToCity={(armyId, targetCityId, mode) =>
                orderArmyToCity(armyId, targetCityId, mode)
              }
              onRetreat={retreatArmy}
              onDefend={setArmyDefend}
              onCaptureCity={captureCityWithArmy}
              onReinforceTroop={reinforceArmyTroops}
            />
          </div>

          <div className="pointer-events-auto shrink-0">
            <GameControls
              isPaused={gameState.isPaused}
              gameSpeed={gameState.gameSpeed}
              hasSavedGame={hasSavedGame}
              lang={lang}
              onTogglePause={togglePause}
              onSetSpeed={setSpeed}
              onSaveGame={saveGame}
              onLoadGame={loadGame}
            />
          </div>
        </div>

        {/* Mobile / Tablet Bottom Drawer & Controls (< lg) */}
        <div className="lg:hidden absolute bottom-0 inset-x-0 z-20 flex flex-col pointer-events-none">
          {mobileTab !== 'none' && (
            <div className="pointer-events-auto max-h-[54vh] overflow-y-auto mx-2 mb-1.5 shadow-2xl">
              {mobileTab === 'city' && (
                <CityPanel
                  city={selectedCity}
                  allCities={gameState.cities}
                  armiesAtCity={armiesAtSelectedCity}
                  activeBattles={gameState.activeBattles}
                  factions={gameState.factions}
                  playerFactionId={gameState.playerFactionId}
                  lang={lang}
                  onRecruitGarrison={recruitCityGarrison}
                  onUpgradeWalls={upgradeCityWalls}
                  onMobilizeArmy={mobilizeNewArmy}
                  onSelectCity={selectCity}
                  onSelectArmy={(aid) => {
                    selectArmy(aid);
                    setMobileTab('army');
                  }}
                />
              )}
              {mobileTab === 'army' && (
                <ArmyPanel
                  army={selectedArmy}
                  playerArmies={playerArmies}
                  cities={gameState.cities}
                  factions={gameState.factions}
                  playerFactionId={gameState.playerFactionId}
                  commandMode={gameState.commandMode}
                  lang={lang}
                  onSelectArmy={selectArmy}
                  onSetCommandMode={(m) => {
                    setCommandMode(m);
                    if (m !== 'none') setMobileTab('none');
                  }}
                  onOrderArmyToCity={(armyId, targetCityId, mode) => {
                    orderArmyToCity(armyId, targetCityId, mode);
                    setMobileTab('none');
                  }}
                  onRetreat={retreatArmy}
                  onDefend={setArmyDefend}
                  onCaptureCity={captureCityWithArmy}
                  onReinforceTroop={reinforceArmyTroops}
                />
              )}
              {mobileTab === 'log' && (
                <BattleLog events={gameState.battleLog} lang={lang} />
              )}
            </div>
          )}

          {/* Mobile Bottom Navigation & Game Controls Strip */}
          <div className="pointer-events-auto bg-[#161411] border-t border-[#3D3426] px-2 py-1.5 flex flex-col gap-1.5">
            <div className="grid grid-cols-4 gap-1 text-xs">
              <button
                type="button"
                onClick={() => setMobileTab('none')}
                className={`py-1.5 rounded flex items-center justify-center gap-1 font-medium cursor-pointer ${
                  mobileTab === 'none'
                    ? 'bg-[#D97706] text-[#12100E] font-semibold'
                    : 'bg-[#221E19] text-[#C9C0B1]'
                }`}
              >
                <MapIcon className="w-3.5 h-3.5" />
                <span>{lang === 'en' ? 'Map' : 'แผนที่'}</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setMobileTab((prev) => (prev === 'city' ? 'none' : 'city'))
                }
                className={`py-1.5 rounded flex items-center justify-center gap-1 font-medium cursor-pointer truncate px-1 ${
                  mobileTab === 'city'
                    ? 'bg-[#D97706] text-[#12100E] font-semibold'
                    : 'bg-[#221E19] text-[#C9C0B1]'
                }`}
              >
                <Castle className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">
                  {selectedCity
                    ? selectedCity.name[lang]
                    : lang === 'en'
                    ? 'City'
                    : 'เมือง'}
                </span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setMobileTab((prev) => (prev === 'army' ? 'none' : 'army'))
                }
                className={`py-1.5 rounded flex items-center justify-center gap-1 font-medium cursor-pointer truncate px-1 ${
                  mobileTab === 'army'
                    ? 'bg-[#D97706] text-[#12100E] font-semibold'
                    : 'bg-[#221E19] text-[#C9C0B1]'
                }`}
              >
                <Swords className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">
                  {selectedArmy
                    ? selectedArmy.general.name[lang]
                    : lang === 'en'
                    ? 'Army'
                    : 'กองทัพ'}
                </span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setMobileTab((prev) => (prev === 'log' ? 'none' : 'log'))
                }
                className={`py-1.5 rounded flex items-center justify-center gap-1 font-medium cursor-pointer ${
                  mobileTab === 'log'
                    ? 'bg-[#D97706] text-[#12100E] font-semibold'
                    : 'bg-[#221E19] text-[#C9C0B1]'
                }`}
              >
                <ScrollText className="w-3.5 h-3.5" />
                <span>{lang === 'en' ? 'Log' : 'บันทึก'}</span>
              </button>
            </div>

            <GameControls
              isPaused={gameState.isPaused}
              gameSpeed={gameState.gameSpeed}
              hasSavedGame={hasSavedGame}
              lang={lang}
              onTogglePause={togglePause}
              onSetSpeed={setSpeed}
              onSaveGame={saveGame}
              onLoadGame={loadGame}
            />
          </div>
        </div>

        {/* Unification Victory Modal */}
        {gameState.screen === 'victory' && (
          <div className="fixed inset-0 z-40 bg-black/80 flex items-center justify-center p-4">
            <div className="max-w-md w-full bg-[#181613] border-2 border-[#F59E0B] rounded-md p-6 text-center shadow-2xl">
              <div className="w-14 h-14 rounded-full bg-[#D97706]/20 border border-[#F59E0B] flex items-center justify-center mx-auto mb-4">
                <Trophy className="w-7 h-7 text-[#F59E0B]" />
              </div>
              <h2 className="font-display font-bold text-2xl text-[#F3ECE0]">
                {lang === 'en'
                  ? 'THE REALM IS UNITED!'
                  : 'รวบรวมแผ่นดินสามก๊กสำเร็จ!'}
              </h2>
              <p className="text-sm text-[#C9C0B1] mt-2 leading-relaxed">
                {lang === 'en'
                  ? `${playerFaction.name.en} under ${playerFaction.rulerName.en} has conquered all eight strategic capitals and brought peace to All Under Heaven.`
                  : `${playerFaction.name.th} ภายใต้การนำของ ${playerFaction.rulerName.th} ได้พิชิตทั้ง 8 หัวเมืองยุทธศาสตร์และรวมแผ่นดินเป็นหนึ่งเดียวสำเร็จ`}
              </p>

              <div className="grid grid-cols-2 gap-2 my-5 bg-[#12100E] border border-[#2C251C] rounded p-3 text-xs">
                <div>
                  <div className="text-[#A89F8E]">
                    {lang === 'en' ? 'Total Troops' : 'กำลังพลรวม'}
                  </div>
                  <div className="font-mono-num font-bold text-base text-[#F59E0B] mt-0.5">
                    {playerFaction.totalMilitaryStrength.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-[#A89F8E]">
                    {lang === 'en' ? 'Completed In' : 'เวลาที่ใช้'}
                  </div>
                  <div className="font-mono-num font-bold text-base text-[#34D399] mt-0.5">
                    {gameState.seasonYear[lang]}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={resetToTitle}
                className="w-full py-2.5 rounded bg-[#D97706] hover:bg-[#B45309] text-[#12100E] font-display font-bold text-sm tracking-wide transition-colors cursor-pointer"
              >
                {lang === 'en' ? 'Play Again' : 'เริ่มสงครามครั้งใหม่'}
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
