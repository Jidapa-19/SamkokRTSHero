import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ZoomIn, ZoomOut, Compass, Crosshair } from 'lucide-react';
import {
  MAP_HEIGHT,
  MAP_WIDTH,
  MOUNTAIN_RANGES,
  RIVERS,
  STRATEGIC_PASSES,
} from '../game/mapData';
import {
  Army,
  City,
  CombatEffect,
  CommandMode,
  Faction,
  FactionId,
  Language,
} from '../game/types';

interface GameMapProps {
  cities: City[];
  armies: Army[];
  factions: Record<FactionId, Faction>;
  selectedCityId: string | null;
  selectedArmyId: string | null;
  commandMode: CommandMode;
  combatEffects: CombatEffect[];
  lang: Language;
  onSelectCity: (cityId: string) => void;
  onSelectArmy: (armyId: string) => void;
  onCancelCommandMode: () => void;
}

interface CameraState {
  x: number;
  y: number;
  scale: number;
}

const MIN_SCALE = 0.52;
const MAX_SCALE = 2.15;

export const GameMap: React.FC<GameMapProps> = ({
  cities,
  armies,
  factions,
  selectedCityId,
  selectedArmyId,
  commandMode,
  combatEffects,
  lang,
  onSelectCity,
  onSelectArmy,
  onCancelCommandMode,
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Store latest props in refs so the 60fps requestAnimationFrame loop never recreates
  const stateRef = useRef({
    cities,
    armies,
    factions,
    selectedCityId,
    selectedArmyId,
    commandMode,
    combatEffects,
    lang,
  });

  useEffect(() => {
    stateRef.current = {
      cities,
      armies,
      factions,
      selectedCityId,
      selectedArmyId,
      commandMode,
      combatEffects,
      lang,
    };
  }, [
    cities,
    armies,
    factions,
    selectedCityId,
    selectedArmyId,
    commandMode,
    combatEffects,
    lang,
  ]);

  const cameraRef = useRef<CameraState>({
    x: 0,
    y: 0,
    scale: 0.85,
  });

  const [zoomPercent, setZoomPercent] = useState<number>(85);
  const hoveredItemRef = useRef<{ type: 'city' | 'army'; id: string } | null>(null);

  // Drag & pinch tracking refs
  const isDraggingRef = useRef<boolean>(false);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const cameraStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const dragMovedDistanceRef = useRef<number>(0);
  const pinchDistanceRef = useRef<number | null>(null);
  const keysHeldRef = useRef<Set<string>>(new Set());

  const clampCamera = useCallback(
    (x: number, y: number, scale: number, viewW: number, viewH: number): CameraState => {
      const clampedScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
      const mapScaledW = MAP_WIDTH * clampedScale;
      const mapScaledH = MAP_HEIGHT * clampedScale;

      const marginX = Math.max(140, viewW * 0.25);
      const marginY = Math.max(140, viewH * 0.25);

      const minX = viewW - mapScaledW - marginX;
      const maxX = marginX;
      const minY = viewH - mapScaledH - marginY;
      const maxY = marginY;

      return {
        x: Math.min(maxX, Math.max(minX, x)),
        y: Math.min(maxY, Math.max(minY, y)),
        scale: clampedScale,
      };
    },
    []
  );

  const centerMap = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const fitScale = Math.min(
      0.95,
      Math.max(0.62, Math.min(rect.width / MAP_WIDTH, rect.height / MAP_HEIGHT) * 0.96)
    );
    const x = (rect.width - MAP_WIDTH * fitScale) / 2;
    const y = (rect.height - MAP_HEIGHT * fitScale) / 2;
    cameraRef.current = clampCamera(x, y, fitScale, rect.width, rect.height);
    setZoomPercent(Math.round(cameraRef.current.scale * 100));
  }, [clampCamera]);

  const focusOnSelected = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const { selectedArmyId: sArmyId, selectedCityId: sCityId, armies: aList, cities: cList } =
      stateRef.current;

    const targetArmy = aList.find((a) => a.id === sArmyId);
    const targetCity = cList.find((c) => c.id === sCityId);
    const targetPos = targetArmy?.position || targetCity?.position;
    if (!targetPos) {
      centerMap();
      return;
    }

    const scale = Math.max(cameraRef.current.scale, 0.92);
    const x = rect.width / 2 - targetPos.x * scale;
    const y = rect.height / 2 - targetPos.y * scale;
    cameraRef.current = clampCamera(x, y, scale, rect.width, rect.height);
    setZoomPercent(Math.round(cameraRef.current.scale * 100));
  }, [centerMap, clampCamera]);

  // Initialize camera and handle ResizeObserver
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const updateCanvasSize = () => {
      const rect = container.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      cameraRef.current = clampCamera(
        cameraRef.current.x,
        cameraRef.current.y,
        cameraRef.current.scale,
        rect.width,
        rect.height
      );
    };

    updateCanvasSize();
    centerMap();

    const observer = new ResizeObserver(() => {
      updateCanvasSize();
    });
    observer.observe(container);

    return () => observer.disconnect();
  }, [centerMap, clampCamera]);

  // Keyboard WASD / Arrow panning + Escape to cancel command mode
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }
      if (e.key === 'Escape') {
        onCancelCommandMode();
      }
      keysHeldRef.current.add(e.key.toLowerCase());
    };

    const onKeyUp = (e: KeyboardEvent) => {
      keysHeldRef.current.delete(e.key.toLowerCase());
    };

    const onBlur = () => {
      keysHeldRef.current.clear();
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [onCancelCommandMode]);

  // Convert screen coordinates to map world coordinates
  const screenToWorld = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const sx = clientX - rect.left;
    const sy = clientY - rect.top;
    return {
      x: (sx - cameraRef.current.x) / cameraRef.current.scale,
      y: (sy - cameraRef.current.y) / cameraRef.current.scale,
    };
  };

  // Hit-test world coordinates for Armies first (top layer), then Cities
  const findHitAtWorld = (wx: number, wy: number) => {
    const { armies: aList, cities: cList, commandMode: cMode } = stateRef.current;

    // If player is in Move or Attack command mode, prioritize City hit-testing so connected cities are easy to click
    if (cMode === 'move' || cMode === 'attack') {
      for (const city of cList) {
        const dist = Math.hypot(wx - city.position.x, wy - city.position.y);
        if (dist <= 40) {
          return { type: 'city' as const, id: city.id };
        }
      }
    }

    // Check armies first
    for (let i = aList.length - 1; i >= 0; i--) {
      const army = aList[i];
      const dist = Math.hypot(wx - army.position.x, wy - army.position.y);
      if (dist <= 24) {
        return { type: 'army' as const, id: army.id };
      }
    }

    // Check cities
    for (const city of cList) {
      const dist = Math.hypot(wx - city.position.x, wy - city.position.y);
      if (dist <= 36) {
        return { type: 'city' as const, id: city.id };
      }
    }

    return null;
  };

  // Zoom around a specific screen point
  const zoomAtPoint = useCallback(
    (deltaScaleFactor: number, screenX: number, screenY: number) => {
      const container = containerRef.current;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      const prevCam = cameraRef.current;
      const newScale = Math.max(
        MIN_SCALE,
        Math.min(MAX_SCALE, prevCam.scale * deltaScaleFactor)
      );

      const worldX = (screenX - prevCam.x) / prevCam.scale;
      const worldY = (screenY - prevCam.y) / prevCam.scale;

      const newX = screenX - worldX * newScale;
      const newY = screenY - worldY * newScale;

      cameraRef.current = clampCamera(newX, newY, newScale, rect.width, rect.height);
      setZoomPercent(Math.round(cameraRef.current.scale * 100));
    },
    [clampCamera]
  );

  // Mouse handlers
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (e.button !== 0) return;
    isDraggingRef.current = true;
    dragMovedDistanceRef.current = 0;
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    cameraStartRef.current = { x: cameraRef.current.x, y: cameraRef.current.y };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const container = containerRef.current;
    if (!container) return;

    if (isDraggingRef.current) {
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      dragMovedDistanceRef.current = Math.hypot(dx, dy);

      const rect = container.getBoundingClientRect();
      cameraRef.current = clampCamera(
        cameraStartRef.current.x + dx,
        cameraStartRef.current.y + dy,
        cameraRef.current.scale,
        rect.width,
        rect.height
      );
      return;
    }

    const worldPos = screenToWorld(e.clientX, e.clientY);
    hoveredItemRef.current = findHitAtWorld(worldPos.x, worldPos.y);
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDraggingRef.current) return;
    isDraggingRef.current = false;

    if (dragMovedDistanceRef.current < 8) {
      const worldPos = screenToWorld(e.clientX, e.clientY);
      const hit = findHitAtWorld(worldPos.x, worldPos.y);
      if (hit) {
        if (hit.type === 'army') {
          onSelectArmy(hit.id);
        } else {
          onSelectCity(hit.id);
        }
      }
    }
  };

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const sx = e.clientX - rect.left;
    const sy = e.clientY - rect.top;
    const factor = e.deltaY < 0 ? 1.12 : 0.89;
    zoomAtPoint(factor, sx, sy);
  };

  // Touch handlers (single-finger pan, two-finger pinch zoom, tap selection)
  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 1) {
      const t = e.touches[0];
      isDraggingRef.current = true;
      pinchDistanceRef.current = null;
      dragMovedDistanceRef.current = 0;
      dragStartRef.current = { x: t.clientX, y: t.clientY };
      cameraStartRef.current = { x: cameraRef.current.x, y: cameraRef.current.y };
    } else if (e.touches.length === 2) {
      isDraggingRef.current = false;
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      pinchDistanceRef.current = Math.hypot(
        t2.clientX - t1.clientX,
        t2.clientY - t1.clientY
      );
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    const container = containerRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();

    if (e.touches.length === 1 && isDraggingRef.current) {
      const t = e.touches[0];
      const dx = t.clientX - dragStartRef.current.x;
      const dy = t.clientY - dragStartRef.current.y;
      dragMovedDistanceRef.current = Math.hypot(dx, dy);

      cameraRef.current = clampCamera(
        cameraStartRef.current.x + dx,
        cameraStartRef.current.y + dy,
        cameraRef.current.scale,
        rect.width,
        rect.height
      );
    } else if (e.touches.length === 2 && pinchDistanceRef.current !== null) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const newDist = Math.hypot(t2.clientX - t1.clientX, t2.clientY - t1.clientY);
      const centerX = (t1.clientX + t2.clientX) / 2 - rect.left;
      const centerY = (t1.clientY + t2.clientY) / 2 - rect.top;

      if (pinchDistanceRef.current > 10) {
        const factor = newDist / pinchDistanceRef.current;
        zoomAtPoint(factor, centerX, centerY);
      }
      pinchDistanceRef.current = newDist;
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (
      isDraggingRef.current &&
      dragMovedDistanceRef.current < 12 &&
      e.changedTouches.length === 1
    ) {
      const t = e.changedTouches[0];
      const worldPos = screenToWorld(t.clientX, t.clientY);
      const hit = findHitAtWorld(worldPos.x, worldPos.y);
      if (hit) {
        if (hit.type === 'army') {
          onSelectArmy(hit.id);
        } else {
          onSelectCity(hit.id);
        }
      }
    }
    if (e.touches.length === 0) {
      isDraggingRef.current = false;
      pinchDistanceRef.current = null;
    }
  };

  // Main 60fps Canvas Render Loop
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();

    const render = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTime = now;

      const canvas = canvasRef.current;
      const container = containerRef.current;
      if (canvas && container) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const rect = container.getBoundingClientRect();
          const dpr = window.devicePixelRatio || 1;

          // Apply continuous keyboard panning
          const keys = keysHeldRef.current;
          if (keys.size > 0) {
            const panSpeed = 420 * dt;
            let panX = 0;
            let panY = 0;
            if (keys.has('w') || keys.has('arrowup')) panY += panSpeed;
            if (keys.has('s') || keys.has('arrowdown')) panY -= panSpeed;
            if (keys.has('a') || keys.has('arrowleft')) panX += panSpeed;
            if (keys.has('d') || keys.has('arrowright')) panX -= panSpeed;
            if (panX !== 0 || panY !== 0) {
              cameraRef.current = clampCamera(
                cameraRef.current.x + panX,
                cameraRef.current.y + panY,
                cameraRef.current.scale,
                rect.width,
                rect.height
              );
            }
          }

          const cam = cameraRef.current;
          const {
            cities: cList,
            armies: aList,
            factions: fMap,
            selectedCityId: sCityId,
            selectedArmyId: sArmyId,
            commandMode: cMode,
            combatEffects: fxList,
            lang: curLang,
          } = stateRef.current;

          ctx.save();
          ctx.scale(dpr, dpr);

          // 1. Dark Ink Outer Void
          ctx.fillStyle = '#12100E';
          ctx.fillRect(0, 0, rect.width, rect.height);

          // Transform into World Space
          ctx.translate(cam.x, cam.y);
          ctx.scale(cam.scale, cam.scale);

          // 2. Antique Silk-Parchment Base Map Surface
          const parchmentGrad = ctx.createRadialGradient(
            MAP_WIDTH * 0.5,
            MAP_HEIGHT * 0.48,
            100,
            MAP_WIDTH * 0.5,
            MAP_HEIGHT * 0.5,
            MAP_WIDTH * 0.75
          );
          parchmentGrad.addColorStop(0, '#E2D5BA');
          parchmentGrad.addColorStop(0.65, '#D2C19E');
          parchmentGrad.addColorStop(1, '#B8A27A');

          ctx.fillStyle = parchmentGrad;
          ctx.fillRect(0, 0, MAP_WIDTH, MAP_HEIGHT);

          // Subtle regional topographical washes
          ctx.fillStyle = 'rgba(138, 115, 78, 0.12)';
          ctx.beginPath();
          ctx.ellipse(350, 600, 320, 290, 0.2, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = 'rgba(120, 145, 115, 0.1)';
          ctx.beginPath();
          ctx.ellipse(1150, 680, 360, 240, -0.15, 0, Math.PI * 2);
          ctx.fill();

          // Subtle Imperial Cartographic Grid Lines
          ctx.strokeStyle = 'rgba(74, 59, 40, 0.11)';
          ctx.lineWidth = 1;
          const gridStep = 160;
          for (let gx = gridStep; gx < MAP_WIDTH; gx += gridStep) {
            ctx.beginPath();
            ctx.moveTo(gx, 24);
            ctx.lineTo(gx, MAP_HEIGHT - 24);
            ctx.stroke();
          }
          for (let gy = gridStep; gy < MAP_HEIGHT; gy += gridStep) {
            ctx.beginPath();
            ctx.moveTo(24, gy);
            ctx.lineTo(MAP_WIDTH - 24, gy);
            ctx.stroke();
          }

          // Map Ornamental Double Border Frame
          ctx.strokeStyle = '#4A3B28';
          ctx.lineWidth = 6;
          ctx.strokeRect(12, 12, MAP_WIDTH - 24, MAP_HEIGHT - 24);
          ctx.strokeStyle = '#6E583D';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(22, 22, MAP_WIDTH - 44, MAP_HEIGHT - 44);

          // 3. Rivers (Yellow River, Yangtze River, Han River)
          for (const river of RIVERS) {
            if (river.points.length < 2) continue;

            // Outer river bank wash
            ctx.beginPath();
            ctx.moveTo(river.points[0].x, river.points[0].y);
            for (let i = 1; i < river.points.length - 1; i++) {
              const xc = (river.points[i].x + river.points[i + 1].x) / 2;
              const yc = (river.points[i].y + river.points[i + 1].y) / 2;
              ctx.quadraticCurveTo(river.points[i].x, river.points[i].y, xc, yc);
            }
            const lastPt = river.points[river.points.length - 1];
            ctx.lineTo(lastPt.x, lastPt.y);

            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.strokeStyle = 'rgba(62, 92, 108, 0.35)';
            ctx.lineWidth = river.width + 8;
            ctx.stroke();

            // Main river ink-teal channel
            ctx.strokeStyle = '#4C7A8C';
            ctx.lineWidth = river.width;
            ctx.stroke();

            // Shimmering water highlight
            ctx.strokeStyle = '#7FA9B8';
            ctx.lineWidth = Math.max(2, river.width * 0.35);
            ctx.stroke();

            // River Name Label
            const midPt = river.points[Math.floor(river.points.length / 2)];
            ctx.save();
            ctx.font = 'italic 600 13px "Cinzel", "Noto Serif Thai", serif';
            ctx.fillStyle = '#2C4C59';
            ctx.textAlign = 'center';
            ctx.fillText(river.name[curLang], midPt.x, midPt.y - river.width - 4);
            ctx.restore();
          }

          // 4. Mountain Ranges (Ink-wash peaks)
          for (const range of MOUNTAIN_RANGES) {
            for (const peak of range.peaks) {
              const w = 48 * peak.scale;
              const h = peak.height;

              // Shadow base
              ctx.fillStyle = 'rgba(72, 60, 46, 0.22)';
              ctx.beginPath();
              ctx.ellipse(peak.x, peak.y + 6, w * 0.9, 12, 0, 0, Math.PI * 2);
              ctx.fill();

              // Left dark ink slope
              ctx.fillStyle = '#594A38';
              ctx.beginPath();
              ctx.moveTo(peak.x - w, peak.y);
              ctx.lineTo(peak.x, peak.y - h);
              ctx.lineTo(peak.x + w * 0.15, peak.y + 4);
              ctx.closePath();
              ctx.fill();

              // Right sunlit parchment-stone slope
              ctx.fillStyle = '#7D6A52';
              ctx.beginPath();
              ctx.moveTo(peak.x, peak.y - h);
              ctx.lineTo(peak.x + w, peak.y);
              ctx.lineTo(peak.x + w * 0.15, peak.y + 4);
              ctx.closePath();
              ctx.fill();

              // Ink brush ridge outline
              ctx.strokeStyle = '#33291F';
              ctx.lineWidth = 2;
              ctx.beginPath();
              ctx.moveTo(peak.x - w, peak.y);
              ctx.lineTo(peak.x, peak.y - h);
              ctx.lineTo(peak.x + w, peak.y);
              ctx.stroke();
            }

            // Mountain Range Label
            const firstPeak = range.peaks[0];
            if (firstPeak) {
              ctx.font = '600 11px "Cinzel", "Noto Serif Thai", serif';
              ctx.fillStyle = '#4A3C2C';
              ctx.textAlign = 'center';
              ctx.fillText(range.name[curLang], firstPeak.x + 40, firstPeak.y + 22);
            }
          }

          // 5. Strategic Passes & Fortifications
          for (const pass of STRATEGIC_PASSES) {
            ctx.save();
            ctx.translate(pass.position.x, pass.position.y);
            ctx.rotate(pass.rotation);

            ctx.fillStyle = '#5C4D3C';
            ctx.strokeStyle = '#2B231A';
            ctx.lineWidth = 1.5;
            ctx.fillRect(-16, -6, 32, 12);
            ctx.strokeRect(-16, -6, 32, 12);

            // Battlement teeth
            for (let bx = -14; bx <= 10; bx += 8) {
              ctx.fillRect(bx, -10, 5, 4);
            }
            ctx.restore();

            ctx.font = '500 10px "Plus Jakarta Sans", "Noto Sans Thai", sans-serif';
            ctx.fillStyle = '#4A3C2C';
            ctx.textAlign = 'center';
            ctx.fillText(pass.name[curLang], pass.position.x, pass.position.y + 19);
          }

          // Determine active army origin city for highlighting valid connected destinations
          const selectedArmy = aList.find((a) => a.id === sArmyId);
          const originCityIdForHighlighter =
            selectedArmy?.currentCityId || sCityId;
          const originCityObj = cList.find((c) => c.id === originCityIdForHighlighter);
          const validTargetCityIds = new Set<string>(
            originCityObj ? originCityObj.connectedCityIds : []
          );

          // 6. Roads Connecting Cities
          const drawnPairs = new Set<string>();
          for (const city of cList) {
            for (const targetId of city.connectedCityIds) {
              const pairKey = [city.id, targetId].sort().join('--');
              if (drawnPairs.has(pairKey)) continue;
              drawnPairs.add(pairKey);

              const targetCity = cList.find((c) => c.id === targetId);
              if (!targetCity) continue;

              const isHighlightedRoute =
                (originCityIdForHighlighter === city.id &&
                  validTargetCityIds.has(targetCity.id)) ||
                (originCityIdForHighlighter === targetCity.id &&
                  validTargetCityIds.has(city.id));

              ctx.save();
              ctx.beginPath();
              ctx.moveTo(city.position.x, city.position.y);
              ctx.lineTo(targetCity.position.x, targetCity.position.y);

              if (isHighlightedRoute && (cMode === 'move' || cMode === 'attack')) {
                ctx.strokeStyle = cMode === 'attack' ? '#DC2626' : '#D97706';
                ctx.lineWidth = 5;
                ctx.setLineDash([10, 6]);
                ctx.lineDashOffset = -(now / 30) % 16;
                ctx.stroke();
              } else if (isHighlightedRoute) {
                ctx.strokeStyle = 'rgba(180, 115, 32, 0.7)';
                ctx.lineWidth = 4;
                ctx.setLineDash([8, 6]);
                ctx.stroke();
              } else {
                // Standard imperial road
                ctx.strokeStyle = 'rgba(87, 68, 44, 0.55)';
                ctx.lineWidth = 3;
                ctx.setLineDash([7, 7]);
                ctx.stroke();
              }
              ctx.restore();
            }
          }

          // 7. Cities
          const pulse = (Math.sin(now / 220) + 1) * 0.5;

          for (const city of cList) {
            const faction = fMap[city.ownerFactionId] || fMap.neutral;
            const isSelected = city.id === sCityId;
            const isHovered =
              hoveredItemRef.current?.type === 'city' &&
              hoveredItemRef.current.id === city.id;
            const isValidCommandTarget =
              (cMode === 'move' || cMode === 'attack') &&
              selectedArmy &&
              validTargetCityIds.has(city.id);

            const { x, y } = city.position;

            // Active Siege Warning Ring
            if (city.underSiege) {
              ctx.save();
              ctx.beginPath();
              ctx.arc(x, y, 39 + pulse * 6, 0, Math.PI * 2);
              ctx.strokeStyle = '#EF4444';
              ctx.lineWidth = 2.5;
              ctx.setLineDash([6, 4]);
              ctx.stroke();
              ctx.restore();
            }

            // Valid command target pulsing ring
            if (isValidCommandTarget) {
              ctx.save();
              ctx.beginPath();
              ctx.arc(x, y, 36 + pulse * 7, 0, Math.PI * 2);
              ctx.strokeStyle = cMode === 'attack' ? '#EF4444' : '#F59E0B';
              ctx.lineWidth = 3;
              ctx.stroke();

              ctx.fillStyle =
                cMode === 'attack'
                  ? 'rgba(239, 68, 68, 0.16)'
                  : 'rgba(245, 158, 11, 0.16)';
              ctx.fill();
              ctx.restore();
            }

            // Selected or Hovered halo
            if (isSelected || isHovered) {
              ctx.save();
              ctx.beginPath();
              ctx.arc(x, y, isSelected ? 33 + pulse * 3 : 31, 0, Math.PI * 2);
              ctx.strokeStyle = isSelected ? '#F59E0B' : '#FFFBEB';
              ctx.lineWidth = isSelected ? 3 : 2;
              ctx.stroke();
              ctx.restore();
            }

            // Outer stone fortification ring (scaled by wallLevel)
            const outerRadius = 22 + city.wallLevel * 1.2;
            ctx.fillStyle = '#26211B';
            ctx.beginPath();
            ctx.arc(x, y, outerRadius, 0, Math.PI * 2);
            ctx.fill();

            ctx.strokeStyle = faction.color;
            ctx.lineWidth = 3.5;
            ctx.stroke();

            // Inner keep square/octagon
            ctx.fillStyle = faction.bannerBg;
            ctx.fillRect(x - 12, y - 12, 24, 24);
            ctx.strokeStyle = '#F3ECE0';
            ctx.lineWidth = 1.2;
            ctx.strokeRect(x - 12, y - 12, 24, 24);

            // Dynasty character / Capital seal inside city node
            ctx.font = 'bold 13px "Cinzel", "Noto Serif Thai", serif';
            ctx.fillStyle = '#F3ECE0';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(city.isCapital ? '★' : faction.dynastySeal, x, y + 0.5);

            // City Name & Garrison Plaque below city
            const cityName = city.name[curLang];
            ctx.font = 'bold 13px "Cinzel", "Noto Serif Thai", serif';
            const nameWidth = ctx.measureText(cityName).width;
            const plaqueW = Math.max(88, nameWidth + 24);
            const plaqueH = 34;
            const plaqueX = x - plaqueW / 2;
            const plaqueY = y + outerRadius + 6;

            ctx.fillStyle = 'rgba(22, 19, 16, 0.9)';
            ctx.strokeStyle = city.underSiege
              ? '#EF4444'
              : isSelected
              ? '#F59E0B'
              : faction.color;
            ctx.lineWidth = isSelected || city.underSiege ? 2 : 1.2;
            ctx.beginPath();
            ctx.roundRect(plaqueX, plaqueY, plaqueW, plaqueH, 4);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = '#F3ECE0';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'top';
            ctx.fillText(cityName, x, plaqueY + 4);

            // Garrison & Wall Level sub-row
            ctx.font = '600 10.5px "JetBrains Mono", monospace';
            ctx.fillStyle = city.underSiege ? '#FCA5A5' : '#D6CEBF';
            ctx.fillText(
              `⚔ ${city.garrison.toLocaleString()} · 🧱Lv.${city.wallLevel}`,
              x,
              plaqueY + 19
            );
          }

          // 8. Marching Trajectory Lines for Active Armies
          for (const army of aList) {
            if (
              (army.status === 'marching' ||
                army.status === 'attacking' ||
                army.status === 'retreating') &&
              army.targetCityId
            ) {
              const targetCity = cList.find((c) => c.id === army.targetCityId);
              if (targetCity) {
                const fac = fMap[army.ownerFactionId] || fMap.neutral;
                ctx.save();
                ctx.beginPath();
                ctx.moveTo(army.position.x, army.position.y);
                ctx.lineTo(targetCity.position.x, targetCity.position.y);
                ctx.strokeStyle =
                  army.status === 'attacking'
                    ? '#EF4444'
                    : army.status === 'retreating'
                    ? '#F59E0B'
                    : fac.secondaryColor;
                ctx.lineWidth = 3;
                ctx.setLineDash([6, 4]);
                ctx.lineDashOffset = -(now / 25) % 10;
                ctx.stroke();
                ctx.restore();
              }
            }
          }

          // 9. Armies (Warlord Battle Banners)
          for (const army of aList) {
            const fac = fMap[army.ownerFactionId] || fMap.neutral;
            const isSelected = army.id === sArmyId;
            const isHovered =
              hoveredItemRef.current?.type === 'army' &&
              hoveredItemRef.current.id === army.id;

            const { x, y } = army.position;
            const bobOffset =
              army.status === 'marching' ||
              army.status === 'attacking' ||
              army.status === 'retreating'
                ? Math.sin(now / 110) * 2.5
                : 0;
            const ay = y + bobOffset;

            // Selection ring under army
            if (isSelected || isHovered) {
              ctx.save();
              ctx.beginPath();
              ctx.arc(x, ay, isSelected ? 22 + pulse * 3 : 20, 0, Math.PI * 2);
              ctx.strokeStyle = isSelected ? '#F59E0B' : '#FFFBEB';
              ctx.lineWidth = 2.5;
              ctx.stroke();
              ctx.restore();
            }

            // Ground shadow
            ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
            ctx.beginPath();
            ctx.ellipse(x, y + 14, 14, 6, 0, 0, Math.PI * 2);
            ctx.fill();

            // Shield / Banner Token Body
            ctx.fillStyle = fac.bannerBg;
            ctx.strokeStyle = isSelected ? '#FBBF24' : '#F3ECE0';
            ctx.lineWidth = isSelected ? 2.5 : 1.6;

            ctx.beginPath();
            ctx.moveTo(x - 13, ay - 13);
            ctx.lineTo(x + 13, ay - 13);
            ctx.lineTo(x + 13, ay + 3);
            ctx.lineTo(x, ay + 15);
            ctx.lineTo(x - 13, ay + 3);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();

            // Status / General Icon inside shield
            ctx.font = 'bold 11px "Plus Jakarta Sans", sans-serif';
            ctx.fillStyle = '#FFFFFF';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const statusSymbol =
              army.status === 'defending'
                ? '🛡'
                : army.status === 'attacking' || army.status === 'capturing'
                ? '⚔'
                : army.status === 'retreating'
                ? '↩'
                : '⚑';
            ctx.fillText(statusSymbol, x, ay - 1);

            // General Name & Troop Count Flag above Army
            const label = `${army.general.name[curLang]} (${army.troopCount.toLocaleString()})`;
            ctx.font = '600 10.5px "Plus Jakarta Sans", "Noto Sans Thai", sans-serif';
            const tw = ctx.measureText(label).width;
            const tagW = tw + 12;
            const tagH = 18;
            const tagX = x - tagW / 2;
            const tagY = ay - 34;

            ctx.fillStyle = 'rgba(20, 18, 15, 0.92)';
            ctx.strokeStyle = fac.color;
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.roundRect(tagX, tagY, tagW, tagH, 3);
            ctx.fill();
            ctx.stroke();

            ctx.fillStyle = '#F3ECE0';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(label, x, tagY + tagH / 2);
          }

          // 10. Combat & Capture Visual Shockwaves
          const nowEpoch = Date.now();
          for (const fx of fxList) {
            const elapsed = (nowEpoch - fx.createdAt) / 1000;
            if (elapsed < 0 || elapsed > 1.8) continue;
            const progress = elapsed / 1.8;
            const alpha = Math.max(0, 1 - progress);
            const radius = 18 + progress * 65;

            ctx.save();
            ctx.beginPath();
            ctx.arc(fx.position.x, fx.position.y, radius, 0, Math.PI * 2);
            ctx.strokeStyle = fx.color;
            ctx.globalAlpha = alpha;
            ctx.lineWidth = fx.type === 'capture' ? 4 : 2.5;
            ctx.stroke();
            ctx.restore();
          }

          ctx.restore();
        }
      }

      animationFrameId = window.requestAnimationFrame(render);
    };

    animationFrameId = window.requestAnimationFrame(render);
    return () => window.cancelAnimationFrame(animationFrameId);
  }, [clampCamera]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full overflow-hidden bg-[#12100E] select-none"
    >
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={() => {
          isDraggingRef.current = false;
          hoveredItemRef.current = null;
        }}
        onWheel={handleWheel}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className={`w-full h-full block touch-none ${
          commandMode !== 'none' ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'
        }`}
      />

      {/* Active Command Mode Banner Overlay */}
      {commandMode !== 'none' && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 pointer-events-auto flex items-center gap-3 px-4 py-2 rounded bg-[#181613] border-2 border-[#D97706] shadow-lg text-xs sm:text-sm text-[#F3ECE0]">
          <Crosshair className="w-4 h-4 text-[#F59E0B] shrink-0" />
          <span>
            {commandMode === 'attack'
              ? lang === 'en'
                ? 'ATTACK MODE: Click a highlighted connected city on the map to launch an assault.'
                : 'โหมดบุกโจมตี: คลิกเลือกเมืองที่เชื่อมต่อบนแผนที่เพื่อเคลื่อนทัพเข้าตี'
              : lang === 'en'
              ? 'MOVE MODE: Click a highlighted connected city on the map to march.'
              : 'โหมดเดินทัพ: คลิกเลือกเมืองที่เชื่อมต่อบนแผนที่เพื่อเคลื่อนพล'}
          </span>
          <button
            type="button"
            onClick={onCancelCommandMode}
            className="px-2 py-0.5 rounded bg-[#2C251E] hover:bg-[#3D3426] text-xs text-[#F59E0B] font-semibold cursor-pointer"
          >
            {lang === 'en' ? 'Cancel (Esc)' : 'ยกเลิก'}
          </button>
        </div>
      )}

      {/* Map Legend & Camera Controls Cluster (Top-Right of Map Canvas) */}
      <div className="absolute top-3 right-3 z-10 flex flex-col items-end gap-2 pointer-events-none">
        {/* Faction Color Key */}
        <div className="pointer-events-auto bg-[#161411]/95 border border-[#3D3426] rounded px-3 py-1.5 flex items-center gap-3 text-[11px] text-[#D6CEBF] shadow">
          {(['wei', 'shu', 'wu', 'neutral'] as FactionId[]).map((fid) => {
            const f = factions[fid];
            return (
              <div key={fid} className="flex items-center gap-1.5 whitespace-nowrap">
                <span
                  className="w-2.5 h-2.5 rounded-xs inline-block border border-white/30"
                  style={{ backgroundColor: f.color }}
                />
                <span>{f.name[lang].split(' ')[0]}</span>
              </div>
            );
          })}
        </div>

        {/* Zoom & Camera Reset Controls */}
        <div className="pointer-events-auto flex items-center gap-1 bg-[#161411]/95 border border-[#3D3426] rounded p-1 shadow">
          <button
            type="button"
            onClick={() => {
              const rect = containerRef.current?.getBoundingClientRect();
              if (rect) zoomAtPoint(1.18, rect.width / 2, rect.height / 2);
            }}
            className="p-1.5 rounded hover:bg-[#2A241D] text-[#E5DEC9] transition-colors cursor-pointer"
            title={lang === 'en' ? 'Zoom In' : 'ขยายแผนที่'}
            aria-label="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <span className="font-mono-num text-xs px-1.5 text-[#A89F8E]">
            {zoomPercent}%
          </span>
          <button
            type="button"
            onClick={() => {
              const rect = containerRef.current?.getBoundingClientRect();
              if (rect) zoomAtPoint(0.84, rect.width / 2, rect.height / 2);
            }}
            className="p-1.5 rounded hover:bg-[#2A241D] text-[#E5DEC9] transition-colors cursor-pointer"
            title={lang === 'en' ? 'Zoom Out' : 'ย่อแผนที่'}
            aria-label="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <div className="w-px h-4 bg-[#3D3426] mx-0.5" />
          <button
            type="button"
            onClick={focusOnSelected}
            className="px-2 py-1 rounded hover:bg-[#2A241D] text-xs text-[#E5DEC9] flex items-center gap-1 transition-colors cursor-pointer"
            title={lang === 'en' ? 'Focus Selected / Reset View' : 'จุดกึ่งกลางแผนที่'}
          >
            <Compass className="w-3.5 h-3.5 text-[#D97706]" />
            <span className="hidden sm:inline">
              {lang === 'en' ? 'Center' : 'กึ่งกลาง'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
