import React from 'react';
import { Play, Pause, Save, FolderOpen, FastForward } from 'lucide-react';
import { Language } from '../game/types';

interface GameControlsProps {
  isPaused: boolean;
  gameSpeed: 1 | 2;
  hasSavedGame: boolean;
  lang: Language;
  onTogglePause: () => void;
  onSetSpeed: (speed: 1 | 2) => void;
  onSaveGame: () => void;
  onLoadGame: () => void;
}

export const GameControls: React.FC<GameControlsProps> = ({
  isPaused,
  gameSpeed,
  hasSavedGame,
  lang,
  onTogglePause,
  onSetSpeed,
  onSaveGame,
  onLoadGame,
}) => {
  return (
    <section className="bg-[#181613] border border-[#3D3426] rounded p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-[#F3ECE0] shadow-lg shrink-0">
      {/* Simulation Loop Controls: Pause / Resume & Speed */}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={onTogglePause}
          className={`px-3 py-1.5 rounded font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
            isPaused
              ? 'bg-[#059669] hover:bg-[#047857] text-white'
              : 'bg-[#D97706] hover:bg-[#B45309] text-[#12100E]'
          }`}
        >
          {isPaused ? (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{lang === 'en' ? 'Resume' : 'เดินเวลาต่อ'}</span>
            </>
          ) : (
            <>
              <Pause className="w-3.5 h-3.5 fill-current" />
              <span>{lang === 'en' ? 'Pause' : 'หยุดเวลา'}</span>
            </>
          )}
        </button>

        <div className="flex items-center rounded bg-[#12100E] border border-[#3D3426] p-0.5">
          <button
            type="button"
            onClick={() => onSetSpeed(1)}
            className={`px-2 py-1 rounded text-[11px] font-mono-num font-semibold transition-colors cursor-pointer ${
              gameSpeed === 1
                ? 'bg-[#3D3426] text-[#F59E0B]'
                : 'text-[#A89F8E] hover:text-[#F3ECE0]'
            }`}
          >
            1x
          </button>
          <button
            type="button"
            onClick={() => onSetSpeed(2)}
            className={`px-2 py-1 rounded text-[11px] font-mono-num font-semibold flex items-center gap-0.5 transition-colors cursor-pointer ${
              gameSpeed === 2
                ? 'bg-[#3D3426] text-[#F59E0B]'
                : 'text-[#A89F8E] hover:text-[#F3ECE0]'
            }`}
          >
            <FastForward className="w-3 h-3" />
            <span>2x</span>
          </button>
        </div>
      </div>

      {/* Persistence Controls: Save Game & Load Game */}
      <div className="flex items-center gap-1.5">
        <button
          type="button"
          onClick={onSaveGame}
          className="px-2.5 py-1.5 rounded bg-[#231F1A] hover:bg-[#302A22] border border-[#4A3F2F] text-xs font-medium text-[#E5DEC9] flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
        >
          <Save className="w-3.5 h-3.5 text-[#D97706]" />
          <span>{lang === 'en' ? 'Save Game' : 'บันทึกเกม'}</span>
        </button>

        <button
          type="button"
          onClick={onLoadGame}
          className={`px-2.5 py-1.5 rounded border text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
            hasSavedGame
              ? 'bg-[#231F1A] hover:bg-[#302A22] border-[#4A3F2F] text-[#E5DEC9]'
              : 'bg-[#1A1714] border-[#2C251C] text-[#78716C] hover:text-[#A89F8E]'
          }`}
        >
          <FolderOpen className="w-3.5 h-3.5 text-[#60A5FA]" />
          <span>{lang === 'en' ? 'Load Game' : 'โหลดเกม'}</span>
        </button>
      </div>
    </section>
  );
};
